﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ImageCall().Wait();
                //MainCallWeek3().Wait();
                Console.ReadLine();
            }
            catch(Exception oexp)
            {
                Console.WriteLine(oexp.Message);
            }
        }

        //homework Week 3.1
        static async Task MainCallWeek3()
        {
            var connString = "mongodb://localhost:27017";
            var client = new MongoClient(connString);
            var db = client.GetDatabase("school");
            var coll = db.GetCollection<BsonDocument>("students");

            var colls = db.GetCollection<Student>("students");

            //var st = (List<Student>)coll1.Find<Student>(a => a.Id == "1.0").Limit(1);
            var list = await coll.Find(new BsonDocument())  //var list = await coll.Find(new BsonDocument("scores.type", "homework"))
                .Limit(50)
                .Sort("{_id:1}")//, 'scores.type':1, 'scores.score':homework}")
                //.Sort("{student_id:1, 'scores.type':1, 'scores.type.score':1}")
                //.Sort(new BsonDocument("student_id", 1))
                .ToListAsync();


            int i = 0;
            foreach (var doc in list)
            {



                var scores = doc["scores"]; //string scr = doc["scores"][0][1].ToString();
                string ls = GetLowestHomeworkScore(scores.ToString());

                var resDoc = await coll.UpdateOneAsync("{_id:" + Convert.ToInt32(doc["_id"]) + "}", "{name:'aaa'}");
                var resDoc1 = await coll.UpdateOneAsync("{_id:" + Convert.ToInt32(doc["_id"]) + "}", "{$pop: {scores.score:" + ls + "}}");


                var fil = Builders<BsonDocument>.Filter.Eq("_id", Convert.ToInt32(doc["_id"]));
                var builder = Builders<BsonDocument>.Filter;
                var fil1 = builder.Eq("scores.score", ls) & builder.Eq("scores.type", "homework");
                
                

                var upd = Builders<BsonDocument>.Update.Pull("", "");

                doc["name"] = "test";
                doc["scores"] = doc["scores"].ToString().Replace("homework", "sss");



                var bd = new BsonDocument { { "_id", Convert.ToInt32(doc.GetValue("_id")) } };
                var bd1 = new BsonDocument(doc);// { { "_id", Convert.ToInt32(doc.GetValue("_id")) } };

                FilterDefinition<BsonDocument> fd = bd;
                //var reult = await coll.UpdateOneAsync(fd, bd);
                string s = bd.ToString();
                //var result = await coll.ReplaceOneAsync( new BsonDocument(bd[0] ,bd));

                var lsd = new BsonDocument();

                bd1.Remove("scores[0]");
                //bd1.Remove("Scores.score:" + ls);

                //var be = bd.GetElement(2);
                
                i++;
                //doc.SetElement(2, "a");

                Console.WriteLine("#:{0},StudentID:{1}, Type:{2}, Score:{3}", doc.GetValue("_id"), doc.GetValue("name"),"","");//, doc.GetValue("scores[0].type"), doc.GetValue("scores[0].score"));

                //string StIDLoop = doc.GetValue("student_id").ToString();
                //if (StID != Convert.ToInt32(doc.GetValue("student_id")).ToString())
                //{
                //    Console.WriteLine("#:{0},StudentID:{1}, Type:{2}, Score:{3}", doc.GetValue("_id"), doc.GetValue("student_id"), doc.GetValue("type"), doc.GetValue("score"));
                //    var bd = new BsonDocument { { "_id", doc.GetValue("_id") } };
                //    var result = await coll.DeleteOneAsync(bd); //var result = await coll.DeleteOneAsync("{_id: objectId(" + doc.GetValue("_id") + ")}");
                //}
                //StID = StIDLoop;

                
            
            }

        }
        
        private static string GetLowestHomeworkScore(string scoresJson)
        {
            JavaScriptSerializer js = new JavaScriptSerializer();
            Score[] scores = js.Deserialize<Score[]>(scoresJson);
            string lowhw = scores.Where(s => s.type.ToLower() == "homework").Min(m => m.score).ToString();
            return lowhw;

            //foreach (var doc in list)
            //{
            //    var scores = doc["scores"];
            //    string ls = GetLowestHomeworkScore(scores.ToString());

            //}

        }
        
        
        //homework Week 2.2
        static async Task MainCall()
        {
            var connString = "mongodb://localhost:27017";
            var client = new MongoClient(connString);
            var db = client.GetDatabase("students");
            var coll = db.GetCollection<BsonDocument>("grades");
            var list = await coll.Find(new BsonDocument("type", "homework"))
                //.Limit(299)
                .Sort("{student_id:1, score:1}")
                //.Sort("{score:1}")
                //.Sort(new BsonDocument("student_id", 1))
                .ToListAsync();
            int i = 0;
            string StID = "";
            foreach(var doc in list)
            {
                i++;
                //Console.WriteLine("#:{0},StudentID:{1}, Type:{2}, Score:{3}", i, doc.GetValue("student_id"), doc.GetValue("type"), doc.GetValue("score"));
                string StIDLoop = doc.GetValue("student_id").ToString();
                if (StID != Convert.ToInt32(doc.GetValue("student_id")).ToString())
                {
                    Console.WriteLine("#:{0},StudentID:{1}, Type:{2}, Score:{3}", doc.GetValue("_id"), doc.GetValue("student_id"), doc.GetValue("type"), doc.GetValue("score"));
                    var bd = new BsonDocument { { "_id", doc.GetValue("_id") } };
                    var result = await coll.DeleteOneAsync(bd);
                    //var result = await coll.DeleteOneAsync("{_id: objectId(" + doc.GetValue("_id") + ")}");
                }
                StID = StIDLoop;
            }

        }

        //homework Week 7.7
        static async Task ImageCall()
        {
            try
            {

                var connString = "mongodb://localhost:27017";
                var client = new MongoClient(connString);
                var db = client.GetDatabase("photoshare");
                var collImg = db.GetCollection<BsonDocument>("images");
                var collImgFil = await collImg.Find(new BsonDocument(), null).ToListAsync();
                var collAlb = db.GetCollection<BsonDocument>("albums");

                foreach (var doc in collImgFil)
                {
                    var idv = doc.GetValue("_id");
                    
                    //var alb4 = collAlb.Find(new BsonDocument("images", idv), null).CountAsync();

                    var alb3 = collAlb.Find(new BsonDocument("images", idv), null).ToListAsync();//.CountAsync();
                    if (alb3.Result.Count == 0)
                    {
                        Console.WriteLine("To Delete" + idv);
                        var bd = new BsonDocument { { "_id", doc.GetValue("_id") } };
                        var result = await collImg.DeleteOneAsync(bd); //var result = await coll.DeleteOneAsync("{_id: objectId(" + doc.GetValue("_id") + ")}");
                    }
                    else
                    {
                        Console.WriteLine("found" + idv + " with" + alb3.Result[0][1].ToString().Length);
                    }
                }
            }
            catch(Exception exp)
            {
                string se = exp.Message;
                Console.WriteLine("Err:" + se);
            }
        }
    }
}
