﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace M101DotNet.WebApp.Models
{
    public class User
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        private void TestFind()
        {
            //1.
            //await blogContext.Users.Find(new BsonDocument())
            //    .ForEachAsync(doc => Console.WriteLine(doc));

            //2.
            //var list = await blogContext.Users.Find(new BsonDocument()).ToCursorAsync();
            //foreach (var doc in list.Current)
            //{
            //    Console.WriteLine(doc);
            //}

            //3.
            //using (var cursor = await blogContext.Users.Find(new BsonDocument()).ToCursorAsync())
            //{
            //    while(await cursor.MoveNextAsync())
            //    {
            //        foreach(var doc in cursor.Current)
            //        {
            //            Console.WriteLine(doc);
            //        }
            //    }
            //}
        }
    }
}