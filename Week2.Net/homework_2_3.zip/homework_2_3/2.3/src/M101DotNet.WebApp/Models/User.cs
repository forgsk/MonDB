﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using MongoDB.Driver;

namespace M101DotNet.WebApp.Models
{
    public class User
    {
        // XXX WORK HERE
        // create an object suitable for insertion into the user collection
        // The homework instructions will tell you the schema that the documents 
        // must follow. Make sure to include Name and Email properties.

        [BsonId]
        [BsonIgnoreIfDefault]
        //[BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public Object Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public bool CreateUser()
        {
            User user = new User();
            user.Name = Name;
            user.Email = Email;
            BlogContext bc = new BlogContext();
            bc.Users.InsertOneAsync(user);
            return true;
        }

        private void TestFind()
        {
            //1.
            //await blogContext.Users.Find(new BsonDocument())
            //    .ForEachAsync(doc => Console.WriteLine(doc));

            //2.
            //var list = await blogContext.Users.Find(new BsonDocument()).ToCursorAsync();
            //foreach (var doc in list.Current)
            //{
            //    Console.WriteLine(doc);
            //}

            //3.
            //using (var cursor = await blogContext.Users.Find(new BsonDocument()).ToCursorAsync())
            //{
            //    while(await cursor.MoveNextAsync())
            //    {
            //        foreach(var doc in cursor.Current)
            //        {
            //            Console.WriteLine(doc);
            //        }
            //    }
            //}
        }
    }
}